from setuptools import find_packages, setup

setup(
    name="pythonal10",
    version="0.1.0",
    author="SDA",
    author_email="citozibrand@gmail.com",
    packages=find_packages(),
    include_package_data=True,
    description="Super Useful Library"
)